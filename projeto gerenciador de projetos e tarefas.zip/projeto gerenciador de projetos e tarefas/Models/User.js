const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
name: { type: String, required: true },
email: { type: String, required: true, unique: true },
// senha em texto puro apenas para exemplo; em produção, usar bcrypt
password: { type: String, required: false },
}, { timestamps: true });
module.exports = mongoose.model('User', UserSchema);
